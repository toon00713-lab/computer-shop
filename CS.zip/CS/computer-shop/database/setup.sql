-- ใช้ไฟล์นี้ไฟล์เดียวสำหรับสร้างตารางและข้อมูลตัวอย่าง
CREATE TABLE IF NOT EXISTS users (
  user_id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE,
  role VARCHAR(20) NOT NULL DEFAULT 'customer' CHECK (role IN ('admin','customer')),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE users ADD COLUMN IF NOT EXISTS email VARCHAR(150);
ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(20) NOT NULL DEFAULT 'customer';
ALTER TABLE users ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS products (
  product_id SERIAL PRIMARY KEY,
  product_name VARCHAR(150) NOT NULL,
  category VARCHAR(100) NOT NULL DEFAULT 'อุปกรณ์คอมพิวเตอร์',
  price NUMERIC(10,2) NOT NULL CHECK (price >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  description TEXT,
  image VARCHAR(255),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  order_id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(user_id),
  total NUMERIC(10,2) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'รอผู้ดูแลยืนยัน',
  items JSONB NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ข้อมูลสินค้าเริ่มต้น
INSERT INTO products (product_name, category, price, stock, description, image)
SELECT v.product_name, v.category, v.price, v.stock, v.description, v.image
FROM (VALUES
 ('คีย์บอร์ดเกมมิ่ง RGB','คีย์บอร์ด',1290,20,'คีย์บอร์ดสำหรับเล่นเกม พร้อมไฟ RGB','keyboard.svg'),
 ('เมาส์เกมมิ่ง','เมาส์',890,35,'เมาส์ตอบสนองรวดเร็ว ใช้งานสะดวก','mouse.svg'),
 ('หน่วยความจำ RAM 16GB','RAM',1590,8,'หน่วยความจำสำหรับคอมพิวเตอร์','ram.svg'),
 ('การ์ดจอ RTX','การ์ดจอ',12900,2,'การ์ดจอสำหรับเล่นเกมและงานกราฟิก','gpu.svg'),
 ('หูฟังเกมมิ่ง','หูฟัง',990,15,'หูฟังพร้อมไมโครโฟน','headset.svg'),
 ('SSD 1TB','อุปกรณ์จัดเก็บข้อมูล',2490,12,'SSD ความจุ 1TB','ssd.svg')
) AS v(product_name,category,price,stock,description,image)
WHERE NOT EXISTS (SELECT 1 FROM products);

-- หลังรันไฟล์นี้ ให้ใช้คำสั่ง npm run create-admin เพื่อสร้างบัญชีผู้ดูแลระบบ toon / 1234 อย่างถูกต้อง
