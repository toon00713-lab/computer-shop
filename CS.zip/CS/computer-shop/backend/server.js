require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const pool = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;
app.use(cors());
app.use(express.json({limit: '8mb'}));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

app.get('/api/health', async (req,res) => {
  try { await pool.query('SELECT 1'); res.json({ok:true,message:'เชื่อมต่อฐานข้อมูลสำเร็จ'}); }
  catch(e) { res.status(500).json({message:'เชื่อมต่อฐานข้อมูลไม่ได้ กรุณาตรวจสอบ .env และ PostgreSQL'}); }
});
app.post('/api/register', async (req,res) => {
  try {
    const {username,password,name,email} = req.body;
    if(!username || !password || !name) return res.status(400).json({message:'กรุณากรอกชื่อ ชื่อผู้ใช้ และรหัสผ่าน'});
    if(password.length < 4) return res.status(400).json({message:'รหัสผ่านต้องมีอย่างน้อย 4 ตัวอักษร'});
    const hash = await bcrypt.hash(password,10);
    const result = await pool.query(
      `INSERT INTO users(username,password_hash,name,email,role) VALUES($1,$2,$3,$4,'customer')
       RETURNING user_id,username,name,email,role`,
      [username.trim(),hash,name.trim(),email ? email.trim() : null]
    );
    res.status(201).json({message:'สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ',user:result.rows[0]});
  } catch(e) {
    if(e.code==='23505') return res.status(409).json({message:'ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้แล้ว'});
    console.error(e); res.status(500).json({message:'สมัครสมาชิกไม่สำเร็จ ตรวจสอบฐานข้อมูลอีกครั้ง'});
  }
});
app.post('/api/login', async (req,res) => {
  try {
    const {username,password} = req.body;
    if(!username || !password) return res.status(400).json({message:'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน'});
    const r = await pool.query('SELECT user_id,username,password_hash,name,email,role FROM users WHERE username=$1',[username.trim()]);
    if(!r.rows.length || !(await bcrypt.compare(password,r.rows[0].password_hash)))
      return res.status(401).json({message:'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'});
    const u=r.rows[0]; res.json({message:'เข้าสู่ระบบสำเร็จ',user:{user_id:u.user_id,username:u.username,name:u.name,email:u.email,role:u.role}});
  } catch(e) { console.error(e); res.status(500).json({message:'เข้าสู่ระบบไม่ได้ กรุณาตรวจสอบฐานข้อมูล'}); }
});
app.patch('/api/profile', async(req,res) => {
  try {
    const {username,currentPassword,name,newPassword} = req.body;
    if(!username || !currentPassword) return res.status(400).json({message:'กรุณากรอกชื่อผู้ใช้และรหัสผ่านปัจจุบัน'});
    const found = await pool.query('SELECT user_id,username,password_hash,name,email,role FROM users WHERE username=$1',[username]);
    if(!found.rows.length || !(await bcrypt.compare(currentPassword,found.rows[0].password_hash)))
      return res.status(401).json({message:'รหัสผ่านปัจจุบันไม่ถูกต้อง'});
    if(!name || !name.trim()) return res.status(400).json({message:'กรุณากรอกชื่อ-นามสกุล'});
    let updated;
    if(newPassword && newPassword.length > 0) {
      if(newPassword.length < 4) return res.status(400).json({message:'รหัสผ่านใหม่ต้องมีอย่างน้อย 4 ตัวอักษร'});
      const hash = await bcrypt.hash(newPassword,10);
      updated = await pool.query('UPDATE users SET name=$1,password_hash=$2 WHERE user_id=$3 RETURNING user_id,username,name,email,role',[name.trim(),hash,found.rows[0].user_id]);
    } else {
      updated = await pool.query('UPDATE users SET name=$1 WHERE user_id=$2 RETURNING user_id,username,name,email,role',[name.trim(),found.rows[0].user_id]);
    }
    res.json({message:newPassword?'แก้ไขชื่อและเปลี่ยนรหัสผ่านสำเร็จ':'แก้ไขชื่อสำเร็จ',user:updated.rows[0]});
  } catch(e) { console.error(e); res.status(500).json({message:'แก้ไขข้อมูลไม่สำเร็จ'}); }
});
app.get('/api/admin/dashboard', async(req,res)=>{
  try {
    if(!await isAdmin(req.query.username)) return res.status(403).json({message:'เฉพาะผู้ดูแลระบบเท่านั้น'});
    const [sales,orders,users,products,daily]=await Promise.all([
      pool.query("SELECT COALESCE(SUM(total),0) AS total_sales FROM orders WHERE status <> 'ยกเลิก'"),
      pool.query('SELECT COUNT(*)::int AS count FROM orders'),
      pool.query('SELECT COUNT(*)::int AS count FROM users'),
      pool.query('SELECT COUNT(*)::int AS count FROM products'),
      pool.query(`SELECT d.day::date AS day, COALESCE(SUM(o.total) FILTER (WHERE o.status <> 'ยกเลิก'),0) AS sales
        FROM generate_series(CURRENT_DATE - INTERVAL '6 days', CURRENT_DATE, INTERVAL '1 day') AS d(day)
        LEFT JOIN orders o ON o.created_at::date=d.day::date
        GROUP BY d.day ORDER BY d.day`)
    ]);
    res.json({totalSales:Number(sales.rows[0].total_sales),orderCount:orders.rows[0].count,userCount:users.rows[0].count,productCount:products.rows[0].count,dailySales:daily.rows.map(r=>({label:new Date(r.day).toLocaleDateString('th-TH',{day:'numeric',month:'short'}),sales:Number(r.sales)}))});
  } catch(e) { console.error(e); res.status(500).json({message:'โหลดแดชบอร์ดไม่สำเร็จ'}); }
});

app.get('/api/products', async(req,res)=>{
  try { const r=await pool.query('SELECT * FROM products ORDER BY product_id'); res.json(r.rows); }
  catch(e){console.error(e);res.status(500).json({message:'โหลดสินค้าไม่ได้'});}
});
app.post('/api/products', async(req,res)=>{
  try {
    const {username,product_name,category,price,stock,description,image,imageData,imageType}=req.body;
    if(!await isAdmin(username)) return res.status(403).json({message:'เฉพาะผู้ดูแลระบบเท่านั้น'});
    if(!product_name || !String(product_name).trim() || price===undefined) return res.status(400).json({message:'กรุณากรอกชื่อสินค้าและราคา'});
    const parsedPrice=Number(price), parsedStock=Number(stock ?? 0);
    if(!Number.isFinite(parsedPrice)||parsedPrice<0) return res.status(400).json({message:'กรุณาระบุราคาให้ถูกต้อง'});
    if(!Number.isInteger(parsedStock)||parsedStock<0) return res.status(400).json({message:'จำนวนสินค้าต้องเป็นเลขจำนวนเต็มตั้งแต่ 0 ขึ้นไป'});
    let imageName=image||'keyboard.svg';
    if(imageData){
      const allowed={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'};
      const ext=allowed[imageType];
      if(!ext) return res.status(400).json({message:'รองรับเฉพาะไฟล์ JPG, PNG หรือ WEBP'});
      const buffer=Buffer.from(imageData,'base64');
      if(!buffer.length||buffer.length>5*1024*1024) return res.status(400).json({message:'รูปภาพต้องมีขนาดไม่เกิน 5 MB'});
      const uploadDir=path.join(__dirname,'..','frontend','images','uploads');
      fs.mkdirSync(uploadDir,{recursive:true});
      const filename=`product-new-${Date.now()}-${Math.random().toString(36).slice(2,7)}.${ext}`;
      fs.writeFileSync(path.join(uploadDir,filename),buffer);
      imageName='uploads/'+filename;
    }
    const r=await pool.query('INSERT INTO products(product_name,category,price,stock,description,image) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',
      [String(product_name).trim(),String(category||'อุปกรณ์คอมพิวเตอร์').trim(),parsedPrice,parsedStock,String(description||''),imageName]);
    res.status(201).json({message:'เพิ่มสินค้าแล้ว',product:r.rows[0]});
  }catch(e){console.error(e);res.status(500).json({message:'เพิ่มสินค้าไม่สำเร็จ'});}
});
app.put('/api/products/:id', async(req,res)=>{
  try {
    const {username,product_name,category,price,stock,description,image,imageData,imageType}=req.body;
    if(!await isAdmin(username)) return res.status(403).json({message:'เฉพาะผู้ดูแลระบบเท่านั้น'});
    if(!product_name || !String(product_name).trim()) return res.status(400).json({message:'กรุณากรอกชื่อสินค้า'});
    const parsedPrice=Number(price), parsedStock=Number(stock);
    if(!Number.isFinite(parsedPrice)||parsedPrice<0) return res.status(400).json({message:'กรุณาระบุราคาให้ถูกต้อง'});
    if(!Number.isInteger(parsedStock)||parsedStock<0) return res.status(400).json({message:'จำนวนสินค้าต้องเป็นเลขจำนวนเต็มตั้งแต่ 0 ขึ้นไป'});
    let imageName=image || 'keyboard.svg';
    if(imageData){
      const allowed={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'};
      const ext=allowed[imageType];
      if(!ext) return res.status(400).json({message:'รองรับเฉพาะไฟล์ JPG, PNG หรือ WEBP'});
      const buffer=Buffer.from(imageData,'base64');
      if(!buffer.length || buffer.length>5*1024*1024) return res.status(400).json({message:'รูปภาพต้องมีขนาดไม่เกิน 5 MB'});
      const uploadDir=path.join(__dirname,'..','frontend','images','uploads');
      fs.mkdirSync(uploadDir,{recursive:true});
      imageName=`product-${req.params.id}-${Date.now()}.${ext}`;
      fs.writeFileSync(path.join(uploadDir,imageName),buffer);
      imageName='uploads/'+imageName;
    }
    const result=await pool.query(
      'UPDATE products SET product_name=$1,category=$2,price=$3,stock=$4,description=$5,image=$6 WHERE product_id=$7 RETURNING *',
      [String(product_name).trim(),String(category||'อุปกรณ์คอมพิวเตอร์').trim(),parsedPrice,parsedStock,String(description||''),imageName,req.params.id]
    );
    if(!result.rows.length) return res.status(404).json({message:'ไม่พบสินค้า'});
    res.json({message:'บันทึกการแก้ไขสินค้าแล้ว',product:result.rows[0]});
  }catch(e){console.error(e);res.status(500).json({message:'แก้ไขสินค้าไม่สำเร็จ'});}
});
app.delete('/api/products/:id', async(req,res)=>{
  try {
    if(!await isAdmin(req.body.username)) return res.status(403).json({message:'เฉพาะผู้ดูแลระบบเท่านั้น'});
    await pool.query('DELETE FROM products WHERE product_id=$1',[req.params.id]);
    res.json({message:'ลบสินค้าแล้ว'});
  }catch(e){console.error(e);res.status(500).json({message:'ลบสินค้าไม่สำเร็จ'});}
});
app.post('/api/orders', async(req,res)=>{
  const client=await pool.connect();
  try {
    const {username,items}=req.body;
    const u=await pool.query("SELECT user_id,role FROM users WHERE username=$1",[username]);
    if(!u.rows.length || u.rows[0].role!=='customer') return res.status(403).json({message:'กรุณาเข้าสู่ระบบด้วยบัญชีลูกค้าก่อนสั่งซื้อ'});
    if(!Array.isArray(items)||!items.length) return res.status(400).json({message:'ตะกร้าสินค้าว่างเปล่า'});
    await client.query('BEGIN');
    let total=0; const clean=[];
    for(const item of items){
      const p=await client.query('SELECT product_id,product_name,price,stock FROM products WHERE product_id=$1 FOR UPDATE',[item.product_id]);
      if(!p.rows.length) throw new Error('ไม่พบสินค้า '+item.product_id);
      const product=p.rows[0], qty=Number(item.quantity);
      if(!Number.isInteger(qty)||qty<1||qty>product.stock) throw new Error('จำนวนสินค้าไม่เพียงพอ: '+product.product_name);
      total+=Number(product.price)*qty;
      clean.push({product_id:product.product_id,name:product.product_name,price:Number(product.price),quantity:qty});
    }
    // หักสต็อกทันทีเมื่อสร้างคำสั่งซื้อ โดยอยู่ใน transaction เดียวกัน
    for(const item of clean){
      const updated=await client.query('UPDATE products SET stock=stock-$1 WHERE product_id=$2 AND stock >= $1',[item.quantity,item.product_id]);
      if(!updated.rowCount) throw new Error('จำนวนสินค้าไม่เพียงพอ กรุณาตรวจสอบสินค้าอีกครั้ง');
    }
    const r=await client.query("INSERT INTO orders(user_id,total,status,items) VALUES($1,$2,'รอผู้ดูแลยืนยัน',$3) RETURNING order_id",[u.rows[0].user_id,total,JSON.stringify(clean)]);
    await client.query('COMMIT'); res.status(201).json({message:'ส่งคำสั่งซื้อแล้ว รอผู้ดูแลระบบยืนยัน',order_id:r.rows[0].order_id,total});
  }catch(e){await client.query('ROLLBACK');res.status(400).json({message:e.message||'สั่งซื้อไม่สำเร็จ'});}
  finally{client.release();}
});
app.get('/api/orders', async(req,res)=>{
  try {
    const {username}=req.query;
    const u=await pool.query('SELECT role,user_id FROM users WHERE username=$1',[username]);
    if(!u.rows.length) return res.status(401).json({message:'กรุณาเข้าสู่ระบบ'});
    const sql=u.rows[0].role==='admin'
      ? `SELECT o.*,u.username,u.name FROM orders o JOIN users u ON u.user_id=o.user_id ORDER BY o.created_at DESC`
      : `SELECT o.*,u.username,u.name FROM orders o JOIN users u ON u.user_id=o.user_id WHERE o.user_id=$1 ORDER BY o.created_at DESC`;
    const r=u.rows[0].role==='admin'?await pool.query(sql):await pool.query(sql,[u.rows[0].user_id]);
    res.json(r.rows);
  }catch(e){console.error(e);res.status(500).json({message:'โหลดคำสั่งซื้อไม่ได้'});}
});
app.patch('/api/orders/:id/status', async(req,res)=>{
  try {
    if(!await isAdmin(req.body.username)) return res.status(403).json({message:'เฉพาะผู้ดูแลระบบเท่านั้น'});
    const {status}=req.body;
    if(!['ยืนยันแล้ว','กำลังจัดส่ง','จัดส่งแล้ว','ยกเลิก'].includes(status)) return res.status(400).json({message:'สถานะไม่ถูกต้อง'});
    const r=await pool.query('UPDATE orders SET status=$1 WHERE order_id=$2 RETURNING *',[status,req.params.id]);
    if(!r.rows.length) return res.status(404).json({message:'ไม่พบคำสั่งซื้อ'});
    res.json({message:'อัปเดตสถานะแล้ว',order:r.rows[0]});
  }catch(e){console.error(e);res.status(500).json({message:'เปลี่ยนสถานะไม่สำเร็จ'});}
});
async function isAdmin(username){
  if(!username) return false;
  const r=await pool.query("SELECT 1 FROM users WHERE username=$1 AND role='admin'",[username]);
  return r.rowCount>0;
}
app.listen(PORT,()=>console.log(`Computer Shop พร้อมใช้งาน: http://localhost:${PORT}`));
