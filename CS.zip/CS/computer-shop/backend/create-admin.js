require("dotenv").config();
const bcrypt = require("bcryptjs");
const pool = require("./db");
(async () => {
  try {
    const hash = await bcrypt.hash("1234", 10);
    await pool.query(
      `INSERT INTO users(username,password_hash,name,email,role) VALUES('toon',$1,'ผู้ดูแลระบบ','toon@example.local','admin') ON CONFLICT(username) DO UPDATE SET password_hash=EXCLUDED.password_hash, role='admin', name='ผู้ดูแลระบบ'`,
      [hash],
    );
    console.log("สร้าง/ปรับบัญชีผู้ดูแลระบบแล้ว: toon / 1234");
  } catch (e) {
    console.error(e.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
